const configureStripe = require('stripe');

const STRIPE_SECRET_KEY =
  process.env.NODE_ENV === 'production'
    ? 'our_secret_key_for_real'
    : 'sk_test_n26rWomssOenZBDp3TfERpob00OSAzz078';

const stripe = configureStripe(STRIPE_SECRET_KEY);

module.exports = stripe;
