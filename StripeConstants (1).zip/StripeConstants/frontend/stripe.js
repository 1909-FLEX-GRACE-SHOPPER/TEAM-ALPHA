// need to provide production publishable key
const STRIPE_PUBLISHABLE =
  process.env.NODE_ENV === 'production'
    ? 'pk_live_MY_PUBLISHABLE_KEY'
    : 'pk_test_Ul901NlqkeQVqQ4UIYmeagMA00Y3LBjYHE';

export default STRIPE_PUBLISHABLE;
